顏色：鉑月銀
LCD尺寸：16-inch / 2.5K (2560 x 1600, WQXGA) 16:10 aspect ratio / 240Hz / OLED / Glossy display / G-Sync / Pantone Validated
處理器：Intel® Core™ Ultra 9 Processor 185H 2.3 GHz (24MB Cache, up to 4.5 GHz, 16 cores, 22 Threads) ; Intel® AI Boost NPU
記憶體：16GB*2 LPDDR5X 7467 on board(Rated speed of RAM module. Actual memory speeds may vary by CPU configuration.)
(Memory Slot / Memory Max.)：(N/A / 32GB)
硬碟：1TB PCIe® 4.0 NVMe™ M.2 SSD
獨立顯卡：NVIDIA® GeForce RTX™ 4060 Laptop GPU 8GB GDDR6
無線網路：Wi-Fi 6E(802.11ax) (Triple band) 2*2 + Bluetooth® 5.3 Wireless Card (*Bluetooth® version may change with OS version different.)
電池：90WHrs, 4S1P, 4-cell Li-ion
AC Adapter：Rectangle Conn, 200W AC Adapter, Output: 20V DC, 10A, 200W, Input: 100-240V AC, 50/60Hz universal
攝影機：1080P FHD IR Camera for Windows Hello
音效：Built-in 3-microphone array, 4-speaker (dual force woofer) system with Smart Amplifier Technology, 2 Tweeters, AI noise-canceling technology, Dolby Atmos, Hi-Res certification, Smart Amp Technology
尺寸：35.4 x 24.6 x 1.49 ~ 1.64 cm
重量：1.85 Kg
作業系統：Windows 11 Home
保固：2年全球保固 + 首年完美保固
