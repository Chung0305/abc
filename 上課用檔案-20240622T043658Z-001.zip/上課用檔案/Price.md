ASUS ROG_華碩
登記送羅技LIFT人體工學垂直滑鼠市價$2590
ROG Zephyrus G16 GU605MV 16吋電競
IntelCoreUltra9 185H/16G×2/RTX4060/1TB/2.5K
$67,999
Intel® Core™ Ultra 9 Processor 185H 2.3 GHz
NVIDIA® GeForce RTX™ 4060 Laptop GPU 8GB GDDR6
2.5K (2560 x 1600, WQXGA) 16:10 aspect ratio / 240Hz / OLED螢幕
贈品
金士頓 Kingston Nucleum 7in1 Type-C 7合一集線器(C-HUBC1-SR-EN)

