1x Thunderbolt™ 4 support DisplayPort™ / power delivery
2x USB 3.2 Gen 2 Type-C support DisplayPort™ / power delivery
2x USB 3.2 Gen 2 Type-A
1x card reader (SD) (UHS-II, 312MB/s)
1x HDMI 2.1 FRL
1x 3.5mm Combo Audio Jack
Backlit Chiclet Keyboard Single Light